package com.haha.spring.model.token;

public enum TokenType {
	BEARER
}
